import { Product, Service, Sale, Return, Expense, User, Transaction, Store } from "../types";

// Initialize localStorage with default values if they don't exist
export const initializeStorage = () => {
  if (!localStorage.getItem('products')) {
    localStorage.setItem('products', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('services')) {
    localStorage.setItem('services', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('sales')) {
    localStorage.setItem('sales', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('returns')) {
    localStorage.setItem('returns', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('expenses')) {
    localStorage.setItem('expenses', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('transactions')) {
    localStorage.setItem('transactions', JSON.stringify([]));
  }
  
  if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify([
      {
        id: '1',
        username: 'admin',
        name: 'Administrator',
        role: 'admin',
        phone: '08123456789',
        permissions: ['manage_products', 'manage_sales', 'view_reports', 'manage_settings', 'view_dashboard', 'manage_users'],
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        username: 'staff',
        name: 'Staff Kasir',
        role: 'cashier',
        phone: '08123456790',
        permissions: ['view_products', 'manage_sales', 'view_basic_reports', 'view_staff_dashboard'],
        createdAt: new Date().toISOString()
      }
    ]));
  }
  
  if (!localStorage.getItem('store')) {
    localStorage.setItem('store', JSON.stringify({
      name: 'ALTEZ CELL',
      address: 'Jl. Contoh No. 123',
      phone: '0838 3030 77',
      email: 'info@altezcell.com'
    }));
  }
};

// Generic get function
export const getItems = <T>(key: string): T[] => {
  const items = localStorage.getItem(key);
  return items ? JSON.parse(items) : [];
};

// Generic save function
export const saveItems = <T>(key: string, items: T[]): void => {
  localStorage.setItem(key, JSON.stringify(items));
};

// Products
export const getProducts = (): Product[] => getItems<Product>('products');
export const saveProducts = (products: Product[]): void => saveItems('products', products);

// Services
export const getServices = (): Service[] => getItems<Service>('services');
export const saveServices = (services: Service[]): void => saveItems('services', services);

// Sales
export const getSales = (): Sale[] => getItems<Sale>('sales');
export const saveSales = (sales: Sale[]): void => saveItems('sales', sales);

// Returns
export const getReturns = (): Return[] => getItems<Return>('returns');
export const saveReturns = (returns: Return[]): void => saveItems('returns', returns);

// Expenses
export const getExpenses = (): Expense[] => getItems<Expense>('expenses');
export const saveExpenses = (expenses: Expense[]): void => saveItems('expenses', expenses);

// Transactions
export const getTransactions = (): Transaction[] => getItems<Transaction>('transactions');
export const saveTransactions = (transactions: Transaction[]): void => saveItems('transactions', transactions);

// Users
export const getUsers = (): User[] => getItems<User>('users');
export const saveUsers = (users: User[]): void => saveItems('users', users);

// Store
export const getStore = (): Store => {
  const store = localStorage.getItem('store');
  return store ? JSON.parse(store) : null;
};

export const saveStore = (store: Store): void => {
  localStorage.setItem('store', JSON.stringify(store));
};

// Role Permissions
type PermissionRole = {
  id: string;
  name: string;
  permissions: string[];
};

export const getRolePermissions = (): PermissionRole[] => {
  const roles = localStorage.getItem('rolePermissions');
  return roles ? JSON.parse(roles) : [];
};

export const saveRolePermissions = (roles: PermissionRole[]): void => {
  localStorage.setItem('rolePermissions', JSON.stringify(roles));
};

// Update product stock
export const updateProductStock = (productId: string, quantity: number): boolean => {
  const products = getProducts();
  const productIndex = products.findIndex(p => p.id === productId);
  
  if (productIndex === -1) return false;
  
  const product = products[productIndex];
  if (product.stock + quantity < 0) return false;
  
  product.stock += quantity;
  product.updatedAt = new Date().toISOString();
  
  products[productIndex] = product;
  saveProducts(products);
  return true;
};
