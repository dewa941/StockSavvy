import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { initializeStorage } from './utils/storageUtils';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import ProductsPage from './pages/ProductsPage';
import ProductFormPage from './pages/ProductFormPage';
import SalesPage from './pages/SalesPage';
import NewSalePage from './pages/NewSalePage';
import SaleDetailPage from './pages/SaleDetailPage';
import ReportsPage from './pages/ReportsPage';
import SettingsPage from './pages/SettingsPage';
import UserManagementPage from './pages/UserManagementPage';
import './index.css';

// Protected route component
const ProtectedRoute = ({ 
  children, 
  requiredPermission 
}: { 
  children: React.ReactNode;
  requiredPermission?: string;
}) => {
  const { isAuthenticated, hasPermission } = useAuth();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  if (requiredPermission && !hasPermission(requiredPermission)) {
    return <Navigate to="/unauthorized" replace />;
  }
  
  return <>{children}</>;
};

function AppRoutes() {
  const { isAuthenticated } = useAuth();
  
  return (
    <Routes>
      <Route path="/login" element={isAuthenticated ? <Navigate to="/" replace /> : <LoginPage />} />
      
      <Route path="/unauthorized" element={
        <ProtectedRoute>
          <div className="min-h-screen flex flex-col items-center justify-center bg-amber-50 p-4">
            <div className="text-center max-w-md">
              <h1 className="text-2xl font-bold text-amber-600 mb-2">Akses Ditolak</h1>
              <p className="text-gray-600 mb-4">Maaf, Anda tidak memiliki izin untuk mengakses halaman tersebut.</p>
              <button 
                onClick={() => window.history.back()} 
                className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600"
              >
                Kembali
              </button>
            </div>
          </div>
        </ProtectedRoute>
      } />
      
      <Route path="/" element={
        <ProtectedRoute>
          <DashboardPage />
        </ProtectedRoute>
      } />
      
      <Route path="/products" element={
        <ProtectedRoute requiredPermission="view_products">
          <ProductsPage />
        </ProtectedRoute>
      } />
      
      <Route path="/products/new" element={
        <ProtectedRoute requiredPermission="manage_products">
          <ProductFormPage />
        </ProtectedRoute>
      } />
      
      <Route path="/products/edit/:id" element={
        <ProtectedRoute requiredPermission="manage_products">
          <ProductFormPage />
        </ProtectedRoute>
      } />
      
      <Route path="/sales" element={
        <ProtectedRoute>
          <SalesPage />
        </ProtectedRoute>
      } />
      
      <Route path="/sales/new" element={
        <ProtectedRoute>
          <NewSalePage />
        </ProtectedRoute>
      } />
      
      <Route path="/sales/:id" element={
        <ProtectedRoute>
          <SaleDetailPage />
        </ProtectedRoute>
      } />
      
      <Route path="/reports" element={
        <ProtectedRoute requiredPermission="view_reports">
          <ReportsPage />
        </ProtectedRoute>
      } />
      
      <Route path="/settings" element={
        <ProtectedRoute requiredPermission="manage_settings">
          <SettingsPage />
        </ProtectedRoute>
      } />
      
      <Route path="/users" element={
        <ProtectedRoute requiredPermission="manage_users">
          <UserManagementPage />
        </ProtectedRoute>
      } />
    </Routes>
  );
}

export function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Load Google Font
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    
    // Initialize local storage data
    initializeStorage();
    
    // Simulate loading
    setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    
    return () => {
      document.head.removeChild(link);
    };
  }, []);

  if (isLoading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-amber-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <h1 className="text-2xl font-bold text-amber-600">ALTEZ CELL</h1>
          <p className="text-gray-600">Loading application...</p>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </Router>
  );
}

export default App;
