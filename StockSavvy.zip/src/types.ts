export type Product = {
  id: string;
  name: string;
  category: string;
  buyPrice: number;
  sellPrice: number;
  stock: number;
  image?: string;
  createdAt: string;
  updatedAt: string;
};

export type Service = {
  id: string;
  name: string;
  price: number;
  description: string;
  createdAt: string;
  updatedAt: string;
};

export type SaleItem = {
  id: string;
  productId?: string;
  serviceId?: string;
  name: string;
  price: number;
  quantity: number;
  total: number;
  type: 'product' | 'service';
};

export type Sale = {
  id: string;
  items: SaleItem[];
  total: number;
  discount: number;
  grandTotal: number;
  payment: number;
  change: number;
  paymentMethod: 'cash' | 'transfer' | 'credit';
  customerName: string;
  customerPhone?: string;
  status: 'completed' | 'cancelled';
  createdAt: string;
  createdBy: string;
};

export type Return = {
  id: string;
  saleId: string;
  items: SaleItem[];
  total: number;
  reason: string;
  status: 'completed' | 'pending';
  createdAt: string;
  createdBy: string;
};

export type Expense = {
  id: string;
  category: string;
  amount: number;
  description: string;
  date: string;
  createdBy: string;
};

export type User = {
  id: string;
  username: string;
  name: string;
  role: 'admin' | 'cashier';
  phone: string;
  email?: string;
  permissions?: string[];
  createdAt: string;
  updatedAt?: string;
};

export type Transaction = {
  id: string;
  type: 'sale' | 'return' | 'expense' | 'purchase';
  amount: number;
  description: string;
  reference: string;
  date: string;
  createdBy: string;
};

export type Store = {
  name: string;
  address: string;
  phone: string;
  email?: string;
  logo?: string;
};
