import { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { getUsers } from '../utils/storageUtils';

type AuthContextType = {
  isAuthenticated: boolean;
  user: { id: string; username: string; name: string; role: string } | null;
  login: (username: string, password: string) => Promise<boolean>;
  verify2FA: (code: string) => Promise<boolean>;
  logout: () => void;
  pending2FA: boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<{ id: string; username: string; name: string; role: string } | null>(null);
  const [pending2FA, setPending2FA] = useState(false);
  const [tempUser, setTempUser] = useState<{ id: string; username: string; name: string; role: string } | null>(null);

  useEffect(() => {
    // Check if user is already logged in
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      setUser(userData);
      setIsAuthenticated(true);
    }
  }, []);

  const login = async (username: string, password: string) => {
    // In a real app, we would validate against a secure backend
    // For this demo, we'll use a simple check against localStorage
    const users = getUsers();
    const foundUser = users.find(u => u.username === username);
    
    if (foundUser) {
      // In a real app, we would verify password hash
      // For demo, let's assume any password works
      setTempUser({
        id: foundUser.id,
        username: foundUser.username,
        name: foundUser.name,
        role: foundUser.role,
      });
      setPending2FA(true);
      return true;
    }
    
    return false;
  };

  const verify2FA = async (code: string) => {
    // In a real app, we would verify against a proper 2FA system
    // For this demo, let's assume "123456" is the correct code
    if (code === "123456" && tempUser) {
      setUser(tempUser);
      setIsAuthenticated(true);
      setPending2FA(false);
      localStorage.setItem('currentUser', JSON.stringify(tempUser));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('currentUser');
  };

  // Function to check if user has permission
  const hasPermission = (permission: string): boolean => {
    if (!user) return false;
    
    // If admin, they have access to everything by default
    if (user.role === 'admin') {
      return true;
    }
    
    // Check if user has custom permissions
    if (user.permissions && user.permissions.includes(permission)) {
      return true;
    }
    
    // Get custom role permissions from localStorage
    const getRolePermissions = () => {
      const roles = localStorage.getItem('rolePermissions');
      return roles ? JSON.parse(roles) : [];
    };
    
    // Define default permissions for different roles
    const defaultPermissions = {
      admin: ['manage_products', 'manage_sales', 'view_reports', 'manage_settings', 'view_dashboard', 'manage_users'],
      cashier: ['view_products', 'manage_sales', 'view_basic_reports', 'view_staff_dashboard']
    };
    
    // Check against custom role permissions
    const rolePermissions = getRolePermissions();
    const userRole = rolePermissions.find(role => role.name === user.role);
    
    if (userRole && userRole.permissions.includes(permission)) {
      return true;
    }
    
    // Check against default role permissions as fallback
    return defaultPermissions[user.role] && defaultPermissions[user.role].includes(permission);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, verify2FA, logout, pending2FA, hasPermission }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
