import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowDown, ArrowUp, ChartBar, ChevronRight, CircleAlert, DollarSign, Package, ShoppingCart, TrendingUp, Users } from 'lucide-react';
import Layout from '../components/Layout';
import { getProducts, getSales, getTransactions, getUsers } from '../utils/storageUtils';
import { format } from 'date-fns';
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useAuth } from '../contexts/AuthContext';

export default function DashboardPage() {
  const { user, hasPermission } = useAuth();
  const [products, setProducts] = useState([]);
  const [sales, setSales] = useState([]);
  const [lowStockProducts, setLowStockProducts] = useState([]);
  const [todaySales, setTodaySales] = useState(0);
  const [totalStock, setTotalStock] = useState(0);
  const [salesData, setSalesData] = useState([]);
  const [salesTrend, setSalesTrend] = useState(0); // Positive is up, negative is down
  const [recentSales, setRecentSales] = useState([]);
  const [topSellingProducts, setTopSellingProducts] = useState([]);

  useEffect(() => {
    // Load data
    const products = getProducts();
    const sales = getSales();
    const users = getUsers();
    setProducts(products);
    setSales(sales);
    
    // Calculate total stock
    const stock = products.reduce((total, product) => total + product.stock, 0);
    setTotalStock(stock);
    
    // Find low stock products (less than 5 items)
    const lowStock = products.filter(product => product.stock < 5);
    setLowStockProducts(lowStock);
    
    // Calculate today's sales
    const today = new Date().toISOString().split('T')[0];
    const todaySales = sales
      .filter(sale => sale.createdAt.startsWith(today) && sale.status === 'completed')
      .reduce((total, sale) => total + sale.grandTotal, 0);
    setTodaySales(todaySales);
    
    // Calculate sales trend (comparing today with yesterday)
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    const yesterdaySales = sales
      .filter(sale => sale.createdAt.startsWith(yesterdayStr) && sale.status === 'completed')
      .reduce((total, sale) => total + sale.grandTotal, 0);
    
    if (yesterdaySales > 0) {
      const trend = ((todaySales - yesterdaySales) / yesterdaySales) * 100;
      setSalesTrend(trend);
    }
    
    // Recent sales (last 5)
    const recent = [...sales]
      .filter(sale => sale.status === 'completed')
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
    setRecentSales(recent);
    
    // Top selling products
    const productSales = {};
    sales.forEach(sale => {
      sale.items.forEach(item => {
        if (item.type === 'product' && item.productId) {
          if (!productSales[item.productId]) {
            productSales[item.productId] = {
              id: item.productId,
              name: item.name,
              quantity: 0,
              revenue: 0
            };
          }
          productSales[item.productId].quantity += item.quantity;
          productSales[item.productId].revenue += item.total;
        }
      });
    });
    
    const topProducts = Object.values(productSales)
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 5);
    setTopSellingProducts(topProducts);
    
    // Prepare chart data (last 7 days)
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return date.toISOString().split('T')[0];
    }).reverse();
    
    const chartData = last7Days.map(date => {
      const daySales = sales
        .filter(sale => sale.createdAt.startsWith(date) && sale.status === 'completed')
        .reduce((total, sale) => total + sale.grandTotal, 0);
      
      return {
        date: format(new Date(date), 'dd/MM'),
        sales: daySales
      };
    });
    
    setSalesData(chartData);
  }, []);

  // Admin Dashboard
  if (user?.role === 'admin') {
    return (
      <Layout title="Dashboard" showBack={false}>
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-2">Welcome, {user.name}</h2>
          <p className="text-gray-600">Your mobile phone store management system</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="flex items-center gap-2 mb-2">
              <ShoppingCart className="text-amber-500" size={20} />
              <span className="font-medium">Today's Sales</span>
            </div>
            <div className="text-2xl font-bold">Rp {todaySales.toLocaleString()}</div>
            <div className="flex items-center mt-1 text-sm">
              {salesTrend > 0 ? (
                <>
                  <ArrowUp className="text-green-500" size={16} />
                  <span className="text-green-500">{Math.abs(salesTrend).toFixed(1)}%</span>
                </>
              ) : salesTrend < 0 ? (
                <>
                  <ArrowDown className="text-red-500" size={16} />
                  <span className="text-red-500">{Math.abs(salesTrend).toFixed(1)}%</span>
                </>
              ) : (
                <span className="text-gray-500">No change</span>
              )}
              <span className="text-gray-500 ml-1">vs yesterday</span>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="flex items-center gap-2 mb-2">
              <Package className="text-blue-500" size={20} />
              <span className="font-medium">Total Products</span>
            </div>
            <div className="text-2xl font-bold">{products.length}</div>
            <div className="text-sm text-gray-500 mt-1">{totalStock} items in stock</div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="flex items-center gap-2 mb-2">
              <Users className="text-purple-500" size={20} />
              <span className="font-medium">Staff Members</span>
            </div>
            <div className="text-2xl font-bold">
              {getUsers().filter(u => u.role === 'cashier').length}
            </div>
            <div className="text-sm text-gray-500 mt-1">Active cashiers</div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="md:col-span-2">
            <div className="bg-white p-4 rounded-lg shadow mb-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-medium">Sales Last 7 Days</h3>
              </div>
              
              <div className="h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsBarChart
                    data={salesData}
                    margin={{ top: 5, right: 5, left: 0, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => [`Rp ${value.toLocaleString()}`, 'Sales']}
                      labelFormatter={(label) => `Date: ${label}`}
                    />
                    <Bar dataKey="sales" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium">Top Selling Products</h3>
                <Link to="/reports" className="text-sm text-amber-600 hover:underline">
                  View All
                </Link>
              </div>
              
              {topSellingProducts.length === 0 ? (
                <div className="text-center py-4 text-gray-500">No sales data yet</div>
              ) : (
                <ul className="divide-y divide-gray-200">
                  {topSellingProducts.map(product => (
                    <li key={product.id} className="py-2">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-gray-500">{product.quantity} units sold</p>
                        </div>
                        <p className="font-medium">Rp {product.revenue.toLocaleString()}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
          
          <div className="md:col-span-1">
            <div className="bg-white p-4 rounded-lg shadow mb-6">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium">Low Stock Alerts</h3>
                <CircleAlert className="text-amber-500" size={18} />
              </div>
              
              {lowStockProducts.length === 0 ? (
                <div className="text-center py-4 text-gray-500">No low stock items</div>
              ) : (
                <ul className="divide-y divide-gray-200">
                  {lowStockProducts.map(product => (
                    <li key={product.id} className="py-2">
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-red-600">Only {product.stock} left in stock</p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium">Recent Sales</h3>
                <Link to="/sales" className="text-sm text-amber-600 hover:underline">
                  View All
                </Link>
              </div>
              
              {recentSales.length === 0 ? (
                <div className="text-center py-4 text-gray-500">No recent sales</div>
              ) : (
                <ul className="divide-y divide-gray-200">
                  {recentSales.map(sale => (
                    <li key={sale.id} className="py-2">
                      <Link to={`/sales/${sale.id}`} className="block hover:bg-gray-50 -mx-4 px-4 py-1 rounded">
                        <p className="font-medium">{sale.customerName}</p>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">
                            {format(new Date(sale.createdAt), 'dd MMM, HH:mm')}
                          </span>
                          <span className="font-medium">Rp {sale.grandTotal.toLocaleString()}</span>
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Link 
            to="/products" 
            className="bg-white p-4 rounded-lg shadow flex items-center justify-between hover:bg-gray-50"
          >
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-full">
                <Package className="text-blue-500" size={20} />
              </div>
              <span className="font-medium">Products</span>
            </div>
            <ChevronRight size={20} className="text-gray-400" />
          </Link>
          
          <Link 
            to="/sales/new" 
            className="bg-white p-4 rounded-lg shadow flex items-center justify-between hover:bg-gray-50"
          >
            <div className="flex items-center gap-3">
              <div className="bg-amber-100 p-2 rounded-full">
                <ShoppingCart className="text-amber-500" size={20} />
              </div>
              <span className="font-medium">New Sale</span>
            </div>
            <ChevronRight size={20} className="text-gray-400" />
          </Link>
          
          <Link 
            to="/reports" 
            className="bg-white p-4 rounded-lg shadow flex items-center justify-between hover:bg-gray-50"
          >
            <div className="flex items-center gap-3">
              <div className="bg-green-100 p-2 rounded-full">
                <ChartBar className="text-green-500" size={20} />
              </div>
              <span className="font-medium">Reports</span>
            </div>
            <ChevronRight size={20} className="text-gray-400" />
          </Link>
          
          <Link 
            to="/settings" 
            className="bg-white p-4 rounded-lg shadow flex items-center justify-between hover:bg-gray-50"
          >
            <div className="flex items-center gap-3">
              <div className="bg-purple-100 p-2 rounded-full">
                <DollarSign className="text-purple-500" size={20} />
              </div>
              <span className="font-medium">Settings</span>
            </div>
            <ChevronRight size={20} className="text-gray-400" />
          </Link>
          
          {hasPermission('manage_users') && (
            <Link 
              to="/users" 
              className="bg-white p-4 rounded-lg shadow flex items-center justify-between hover:bg-gray-50"
            >
              <div className="flex items-center gap-3">
                <div className="bg-indigo-100 p-2 rounded-full">
                  <Users className="text-indigo-500" size={20} />
                </div>
                <span className="font-medium">User Management</span>
              </div>
              <ChevronRight size={20} className="text-gray-400" />
            </Link>
          )}
        </div>
      </Layout>
    );
  }
  
  // Staff Dashboard (Cashier)
  return (
    <Layout title="Dashboard" showBack={false}>
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-2">Welcome, {user?.name}</h2>
        <p className="text-gray-600">Mobile phone store cashier system</p>
      </div>
      
      <div className="bg-gradient-to-r from-amber-500 to-amber-600 rounded-lg shadow-lg p-6 mb-6 text-white">
        <h3 className="text-xl font-semibold mb-2">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-4 mt-4">
          <Link
            to="/sales/new"
            className="bg-white bg-opacity-20 backdrop-blur-sm rounded-lg p-4 flex flex-col items-center hover:bg-opacity-30 transition-all"
          >
            <ShoppingCart size={32} className="mb-2" />
            <span className="font-medium">New Sale</span>
          </Link>
          <Link
            to="/sales"
            className="bg-white bg-opacity-20 backdrop-blur-sm rounded-lg p-4 flex flex-col items-center hover:bg-opacity-30 transition-all"
          >
            <FileText size={32} className="mb-2" />
            <span className="font-medium">View Sales</span>
          </Link>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center gap-2 mb-2">
            <ShoppingCart className="text-amber-500" size={20} />
            <span className="font-medium">Today's Sales</span>
          </div>
          <div className="text-2xl font-bold">Rp {todaySales.toLocaleString()}</div>
          <div className="flex items-center mt-1 text-sm">
            {salesTrend > 0 ? (
              <>
                <ArrowUp className="text-green-500" size={16} />
                <span className="text-green-500">{Math.abs(salesTrend).toFixed(1)}%</span>
              </>
            ) : salesTrend < 0 ? (
              <>
                <ArrowDown className="text-red-500" size={16} />
                <span className="text-red-500">{Math.abs(salesTrend).toFixed(1)}%</span>
              </>
            ) : (
              <span className="text-gray-500">No change</span>
            )}
            <span className="text-gray-500 ml-1">vs yesterday</span>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex justify-between items-center mb-3">
            <h3 className="font-medium">Recent Sales</h3>
            <Link to="/sales" className="text-sm text-amber-600 hover:underline">
              View All
            </Link>
          </div>
          
          {recentSales.length === 0 ? (
            <div className="text-center py-4 text-gray-500">No recent sales</div>
          ) : (
            <ul className="divide-y divide-gray-200">
              {recentSales.slice(0, 3).map(sale => (
                <li key={sale.id} className="py-2">
                  <Link to={`/sales/${sale.id}`} className="block hover:bg-gray-50 -mx-4 px-4 py-1 rounded">
                    <p className="font-medium">{sale.customerName}</p>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">
                        {format(new Date(sale.createdAt), 'dd MMM, HH:mm')}
                      </span>
                      <span className="font-medium">Rp {sale.grandTotal.toLocaleString()}</span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-medium">Low Stock Products</h3>
          <CircleAlert className="text-amber-500" size={18} />
        </div>
        
        {lowStockProducts.length === 0 ? (
          <div className="text-center py-4 text-gray-500">No low stock items</div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {lowStockProducts.slice(0, 5).map(product => (
              <li key={product.id} className="py-2">
                <p className="font-medium">{product.name}</p>
                <p className="text-sm text-red-600">Only {product.stock} left in stock</p>
              </li>
            ))}
          </ul>
        )}
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <Link 
          to="/products" 
          className="bg-white p-4 rounded-lg shadow flex items-center justify-between hover:bg-gray-50"
        >
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 p-2 rounded-full">
              <Package className="text-blue-500" size={20} />
            </div>
            <span className="font-medium">View Products</span>
          </div>
          <ChevronRight size={20} className="text-gray-400" />
        </Link>
        
        <Link 
          to="/sales/new" 
          className="bg-white p-4 rounded-lg shadow flex items-center justify-between hover:bg-gray-50"
        >
          <div className="flex items-center gap-3">
            <div className="bg-amber-100 p-2 rounded-full">
              <ShoppingCart className="text-amber-500" size={20} />
            </div>
            <span className="font-medium">New Sale</span>
          </div>
          <ChevronRight size={20} className="text-gray-400" />
        </Link>
      </div>
    </Layout>
  );
}
