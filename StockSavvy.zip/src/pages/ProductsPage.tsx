import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Pencil, Plus, Search, Trash } from 'lucide-react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { getProducts, saveProducts } from '../utils/storageUtils';
import { Product } from '../types';

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredProducts(products);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = products.filter(product => 
        product.name.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query)
      );
      setFilteredProducts(filtered);
    }
  }, [searchQuery, products]);

  const loadProducts = () => {
    const loadedProducts = getProducts();
    setProducts(loadedProducts);
    setFilteredProducts(loadedProducts);
  };

  const handleDeleteClick = (product: Product) => {
    setProductToDelete(product);
    setShowDeleteModal(true);
  };

  const confirmDelete = () => {
    if (productToDelete) {
      const updatedProducts = products.filter(p => p.id !== productToDelete.id);
      saveProducts(updatedProducts);
      setProducts(updatedProducts);
      setFilteredProducts(updatedProducts);
      setShowDeleteModal(false);
      setProductToDelete(null);
    }
  };

  return (
    <Layout title="Products">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Product List</h2>
        {useAuth().hasPermission('manage_products') && (
          <Link 
            to="/products/new" 
            className="bg-amber-500 text-white p-2 rounded-full hover:bg-amber-600"
          >
            <Plus size={20} />
          </Link>
        )}
      </div>

      <div className="relative mb-4">
        <input
          type="text"
          placeholder="Search products..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
        />
        <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
      </div>

      <div className="bg-white rounded-lg shadow">
        {filteredProducts.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            {searchQuery ? 'No products found matching your search' : 'No products yet. Add your first product!'}
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {filteredProducts.map(product => (
              <li key={product.id} className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">{product.name}</h3>
                    <p className="text-sm text-gray-500">Stock: {product.stock} | Category: {product.category}</p>
                    <p className="text-sm font-semibold">Rp {product.sellPrice.toLocaleString()}</p>
                  </div>
                  <div className="flex space-x-2">
                    {useAuth().hasPermission('manage_products') ? (
                      <>
                        <Link 
                          to={`/products/edit/${product.id}`} 
                          className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"
                        >
                          <Pencil size={18} />
                        </Link>
                        <button 
                          onClick={() => handleDeleteClick(product)} 
                          className="p-2 text-red-600 hover:bg-red-100 rounded-full"
                        >
                          <Trash size={18} />
                        </button>
                      </>
                    ) : (
                      <Link
                        to={`/products`}
                        className="p-2 text-gray-500"
                        onClick={(e) => e.preventDefault()}
                      >
                        <span className="text-xs text-gray-500">View Only</span>
                      </Link>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="bg-white rounded-lg p-6 max-w-sm mx-4">
            <h3 className="text-lg font-semibold mb-4">Confirm Delete</h3>
            <p className="mb-6">Are you sure you want to delete "{productToDelete?.name}"? This action cannot be undone.</p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
