import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import Layout from '../components/Layout';
import { getProducts, saveProducts } from '../utils/storageUtils';
import { Product } from '../types';

export default function ProductFormPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const isEditing = Boolean(id);
  
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [buyPrice, setBuyPrice] = useState('');
  const [sellPrice, setSellPrice] = useState('');
  const [stock, setStock] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isEditing && id) {
      const products = getProducts();
      const product = products.find(p => p.id === id);
      
      if (product) {
        setName(product.name);
        setCategory(product.category);
        setBuyPrice(product.buyPrice.toString());
        setSellPrice(product.sellPrice.toString());
        setStock(product.stock.toString());
      } else {
        navigate('/products');
      }
    }
  }, [id, isEditing, navigate]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!name.trim()) newErrors.name = 'Product name is required';
    if (!category.trim()) newErrors.category = 'Category is required';
    
    if (!buyPrice.trim()) {
      newErrors.buyPrice = 'Buy price is required';
    } else if (isNaN(Number(buyPrice)) || Number(buyPrice) < 0) {
      newErrors.buyPrice = 'Buy price must be a positive number';
    }
    
    if (!sellPrice.trim()) {
      newErrors.sellPrice = 'Sell price is required';
    } else if (isNaN(Number(sellPrice)) || Number(sellPrice) < 0) {
      newErrors.sellPrice = 'Sell price must be a positive number';
    }
    
    if (!stock.trim()) {
      newErrors.stock = 'Stock is required';
    } else if (isNaN(Number(stock)) || !Number.isInteger(Number(stock)) || Number(stock) < 0) {
      newErrors.stock = 'Stock must be a positive integer';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) return;
    
    const products = getProducts();
    const now = new Date().toISOString();
    
    if (isEditing && id) {
      const updatedProducts = products.map(p => {
        if (p.id === id) {
          return {
            ...p,
            name,
            category,
            buyPrice: Number(buyPrice),
            sellPrice: Number(sellPrice),
            stock: Number(stock),
            updatedAt: now
          };
        }
        return p;
      });
      
      saveProducts(updatedProducts);
    } else {
      const newProduct: Product = {
        id: uuidv4(),
        name,
        category,
        buyPrice: Number(buyPrice),
        sellPrice: Number(sellPrice),
        stock: Number(stock),
        createdAt: now,
        updatedAt: now
      };
      
      saveProducts([...products, newProduct]);
    }
    
    navigate('/products');
  };

  return (
    <Layout title={isEditing ? 'Edit Product' : 'Add Product'} showBack={true}>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
            Product Name
          </label>
          <input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent ${
              errors.name ? 'border-red-500' : 'border-gray-300'
            }`}
          />
          {errors.name && <p className="mt-1 text-sm text-red-500">{errors.name}</p>}
        </div>
        
        <div>
          <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
            Category
          </label>
          <input
            id="category"
            type="text"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent ${
              errors.category ? 'border-red-500' : 'border-gray-300'
            }`}
          />
          {errors.category && <p className="mt-1 text-sm text-red-500">{errors.category}</p>}
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label htmlFor="buyPrice" className="block text-sm font-medium text-gray-700 mb-1">
              Buy Price (Rp)
            </label>
            <input
              id="buyPrice"
              type="number"
              value={buyPrice}
              onChange={(e) => setBuyPrice(e.target.value)}
              className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent ${
                errors.buyPrice ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.buyPrice && <p className="mt-1 text-sm text-red-500">{errors.buyPrice}</p>}
          </div>
          
          <div>
            <label htmlFor="sellPrice" className="block text-sm font-medium text-gray-700 mb-1">
              Sell Price (Rp)
            </label>
            <input
              id="sellPrice"
              type="number"
              value={sellPrice}
              onChange={(e) => setSellPrice(e.target.value)}
              className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent ${
                errors.sellPrice ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.sellPrice && <p className="mt-1 text-sm text-red-500">{errors.sellPrice}</p>}
          </div>
        </div>
        
        <div>
          <label htmlFor="stock" className="block text-sm font-medium text-gray-700 mb-1">
            Stock
          </label>
          <input
            id="stock"
            type="number"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent ${
              errors.stock ? 'border-red-500' : 'border-gray-300'
            }`}
          />
          {errors.stock && <p className="mt-1 text-sm text-red-500">{errors.stock}</p>}
        </div>
        
        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={() => navigate('/products')}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600"
          >
            {isEditing ? 'Update Product' : 'Add Product'}
          </button>
        </div>
      </form>
    </Layout>
  );
}
