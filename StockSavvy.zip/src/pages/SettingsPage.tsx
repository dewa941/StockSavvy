import { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { getStore, saveStore, getRolePermissions, saveRolePermissions } from '../utils/storageUtils';
import { Store } from '../types';
import { Pen, Plus, Save, Trash } from 'lucide-react';

type PermissionRole = {
  id: string;
  name: string;
  permissions: string[];
};

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('store');
  const [store, setStore] = useState<Store>({
    name: '',
    address: '',
    phone: '',
    email: '',
    logo: '',
  });
  
  const [saved, setSaved] = useState(false);
  const [permissionSaved, setPermissionSaved] = useState(false);
  const [roles, setRoles] = useState<PermissionRole[]>([]);
  const [isAddingRole, setIsAddingRole] = useState(false);
  const [isEditingRole, setIsEditingRole] = useState(false);
  const [currentRole, setCurrentRole] = useState<PermissionRole>({
    id: '',
    name: '',
    permissions: []
  });

  // List of all possible permissions
  const availablePermissions = [
    { id: 'view_dashboard', label: 'View Dashboard' },
    { id: 'view_products', label: 'View Products' },
    { id: 'manage_products', label: 'Manage Products' },
    { id: 'view_sales', label: 'View Sales' },
    { id: 'manage_sales', label: 'Manage Sales' },
    { id: 'view_reports', label: 'View Reports' },
    { id: 'view_basic_reports', label: 'View Basic Reports' },
    { id: 'manage_settings', label: 'Manage Settings' },
    { id: 'manage_users', label: 'Manage Users' }
  ];

  useEffect(() => {
    const storeData = getStore();
    if (storeData) {
      setStore(storeData);
    }

    const rolesData = getRolePermissions();
    if (rolesData) {
      setRoles(rolesData);
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setStore(prev => ({
      ...prev,
      [name]: value
    }));
    setSaved(false);
  };

  const handleRoleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCurrentRole(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePermissionChange = (permissionId: string) => {
    setCurrentRole(prev => {
      const permissions = [...prev.permissions];
      
      if (permissions.includes(permissionId)) {
        return {
          ...prev,
          permissions: permissions.filter(p => p !== permissionId)
        };
      } else {
        return {
          ...prev,
          permissions: [...permissions, permissionId]
        };
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveStore(store);
    setSaved(true);
    
    setTimeout(() => {
      setSaved(false);
    }, 3000);
  };

  const addRole = () => {
    setIsAddingRole(true);
    setCurrentRole({
      id: Date.now().toString(),
      name: '',
      permissions: ['view_dashboard', 'view_sales', 'view_reports'] // Default permissions
    });
  };

  const editRole = (role: PermissionRole) => {
    setIsEditingRole(true);
    setCurrentRole({...role});
  };

  const deleteRole = (roleId: string) => {
    const updatedRoles = roles.filter(role => role.id !== roleId);
    setRoles(updatedRoles);
    saveRolePermissions(updatedRoles);
    setPermissionSaved(true);
    
    setTimeout(() => {
      setPermissionSaved(false);
    }, 3000);
  };

  const saveRole = () => {
    if (!currentRole.name.trim()) {
      alert('Role name is required');
      return;
    }

    let updatedRoles;
    if (isEditingRole) {
      updatedRoles = roles.map(role => 
        role.id === currentRole.id ? currentRole : role
      );
    } else {
      updatedRoles = [...roles, currentRole];
    }

    setRoles(updatedRoles);
    saveRolePermissions(updatedRoles);
    setPermissionSaved(true);
    setIsAddingRole(false);
    setIsEditingRole(false);
    
    setTimeout(() => {
      setPermissionSaved(false);
    }, 3000);
  };

  const cancelRoleEdit = () => {
    setIsAddingRole(false);
    setIsEditingRole(false);
  };

  return (
    <Layout title="Settings">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-lg shadow mb-6">
          <div className="flex border-b">
            <button 
              className={`px-4 py-2 font-medium ${activeTab === 'store' ? 'border-b-2 border-amber-500 text-amber-600' : 'text-gray-500'}`}
              onClick={() => setActiveTab('store')}
            >
              Store Settings
            </button>
            <button 
              className={`px-4 py-2 font-medium ${activeTab === 'permissions' ? 'border-b-2 border-amber-500 text-amber-600' : 'text-gray-500'}`}
              onClick={() => setActiveTab('permissions')}
            >
              Permissions
            </button>
          </div>
        </div>

        {activeTab === 'store' && (
          <>
            <h2 className="text-xl font-semibold mb-4">Store Settings</h2>
            
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-6">
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Store Name
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={store.name}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                    Address
                  </label>
                  <textarea
                    id="address"
                    name="address"
                    value={store.address}
                    onChange={handleChange}
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    id="phone"
                    name="phone"
                    type="text"
                    value={store.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={store.email || ''}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                  />
                </div>
                
                <div className="pt-4">
                  <button
                    type="submit"
                    className="w-full px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors"
                  >
                    Save Settings
                  </button>
                  
                  {saved && (
                    <p className="text-center text-green-600 mt-2">
                      Settings saved successfully!
                    </p>
                  )}
                </div>
              </div>
            </form>
            
            <div className="mt-8 bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-medium mb-4">About</h3>
              <p className="text-gray-600">ALTEZ CELL - Mobile Phone Store Management</p>
              <p className="text-gray-600">Version 1.0.0</p>
              <p className="text-gray-600 mt-2">© 2023 ALTEZ CELL. All rights reserved.</p>
            </div>
          </>
        )}

        {activeTab === 'permissions' && (
          <>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Permission Roles</h2>
              {!isAddingRole && !isEditingRole && (
                <button
                  onClick={addRole}
                  className="flex items-center gap-1 px-3 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600"
                >
                  <Plus size={18} />
                  <span>Add Role</span>
                </button>
              )}
            </div>

            {permissionSaved && (
              <div className="mb-4 p-3 bg-green-100 text-green-700 rounded-lg">
                Permissions saved successfully!
              </div>
            )}

            {(isAddingRole || isEditingRole) ? (
              <div className="bg-white rounded-lg shadow p-6 mb-6">
                <h3 className="font-medium mb-4">{isEditingRole ? 'Pen Role' : 'Add New Role'}</h3>
                
                <div className="space-y-4">
                  <div>
                    <label htmlFor="roleName" className="block text-sm font-medium text-gray-700 mb-1">
                      Role Name
                    </label>
                    <input
                      id="roleName"
                      name="name"
                      type="text"
                      value={currentRole.name}
                      onChange={handleRoleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                      placeholder="e.g., Cashier, Manager"
                      required
                    />
                  </div>
                  
                  <div>
                    <p className="block text-sm font-medium text-gray-700 mb-2">Permissions</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {availablePermissions.map(permission => (
                        <div key={permission.id} className="flex items-center">
                          <input
                            id={`perm-${permission.id}`}
                            type="checkbox"
                            checked={currentRole.permissions.includes(permission.id)}
                            onChange={() => handlePermissionChange(permission.id)}
                            className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300 rounded"
                          />
                          <label htmlFor={`perm-${permission.id}`} className="ml-2 block text-sm text-gray-700">
                            {permission.label}
                          </label>
                        </div>
                      ))}
                    </div>
                    <p className="text-sm text-gray-500 mt-2">
                      Note: Non-admin roles will only see dashboard, sales, and reports menus regardless of permissions.
                    </p>
                  </div>
                  
                  <div className="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={cancelRoleEdit}
                      className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={saveRole}
                      className="flex items-center gap-1 px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600"
                    >
                      <Save size={18} />
                      <span>Save Role</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <>
                {roles.length === 0 ? (
                  <div className="bg-white rounded-lg shadow p-6 text-center">
                    <p className="text-gray-500 mb-4">No custom permission roles defined yet.</p>
                    <button
                      onClick={addRole}
                      className="inline-flex items-center gap-1 px-3 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600"
                    >
                      <Plus size={18} />
                      <span>Create First Role</span>
                    </button>
                  </div>
                ) : (
                  <div className="bg-white rounded-lg shadow">
                    <ul className="divide-y divide-gray-200">
                      {roles.map(role => (
                        <li key={role.id} className="p-4">
                          <div className="flex justify-between items-center">
                            <div>
                              <h3 className="font-medium">{role.name}</h3>
                              <p className="text-sm text-gray-500">
                                {role.permissions.length} permissions assigned
                              </p>
                            </div>
                            <div className="flex space-x-2">
                              <button 
                                onClick={() => editRole(role)} 
                                className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"
                              >
                                <Pen size={18} />
                              </button>
                              <button 
                                onClick={() => deleteRole(role.id)} 
                                className="p-2 text-red-600 hover:bg-red-100 rounded-full"
                              >
                                <Trash size={18} />
                              </button>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </>
            )}
          </>
        )}
      </div>
    </Layout>
  );
}
