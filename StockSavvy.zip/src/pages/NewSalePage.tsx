import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import { Minus, Plus, Search, ShoppingCart, Trash } from 'lucide-react';
import Layout from '../components/Layout';
import { getProducts, getSales, saveSales, updateProductStock } from '../utils/storageUtils';
import { Product, SaleItem, Sale } from '../types';
import { useAuth } from '../contexts/AuthContext';

export default function NewSalePage() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const [products, setProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [cartItems, setCartItems] = useState<SaleItem[]>([]);
  
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'transfer' | 'credit'>('cash');
  const [payment, setPayment] = useState('');
  const [discount, setDiscount] = useState('0');
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredProducts(products);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = products.filter(product => 
        product.name.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query)
      );
      setFilteredProducts(filtered);
    }
  }, [searchQuery, products]);

  const loadProducts = () => {
    const loadedProducts = getProducts();
    setProducts(loadedProducts);
    setFilteredProducts(loadedProducts);
  };

  const addToCart = (product: Product) => {
    // Check if product is already in cart
    const existingItemIndex = cartItems.findIndex(
      item => item.productId === product.id && item.type === 'product'
    );

    if (existingItemIndex !== -1) {
      // Increment quantity if already in cart
      const updatedCartItems = [...cartItems];
      const item = updatedCartItems[existingItemIndex];
      const newQuantity = item.quantity + 1;
      
      // Check if there's enough stock
      if (newQuantity > product.stock) {
        setErrors({ stock: `Only ${product.stock} items available in stock` });
        return;
      }
      
      updatedCartItems[existingItemIndex] = {
        ...item,
        quantity: newQuantity,
        total: product.sellPrice * newQuantity
      };
      
      setCartItems(updatedCartItems);
    } else {
      // Add new item to cart
      if (product.stock <= 0) {
        setErrors({ stock: 'Product is out of stock' });
        return;
      }
      
      const newItem: SaleItem = {
        id: uuidv4(),
        productId: product.id,
        name: product.name,
        price: product.sellPrice,
        quantity: 1,
        total: product.sellPrice,
        type: 'product'
      };
      
      setCartItems([...cartItems, newItem]);
    }
    
    setErrors({});
  };

  const updateQuantity = (itemId: string, newQuantity: number) => {
    const updatedCartItems = cartItems.map(item => {
      if (item.id === itemId) {
        // For products, check stock
        if (item.type === 'product' && item.productId) {
          const product = products.find(p => p.id === item.productId);
          if (product && newQuantity > product.stock) {
            setErrors({ stock: `Only ${product.stock} items available in stock` });
            return item;
          }
        }
        
        return {
          ...item,
          quantity: newQuantity,
          total: item.price * newQuantity
        };
      }
      return item;
    });
    
    setCartItems(updatedCartItems);
    setErrors({});
  };

  const removeFromCart = (itemId: string) => {
    setCartItems(cartItems.filter(item => item.id !== itemId));
  };

  const calculateTotal = () => {
    return cartItems.reduce((sum, item) => sum + item.total, 0);
  };

  const calculateGrandTotal = () => {
    const total = calculateTotal();
    const discountAmount = parseFloat(discount) || 0;
    return total - discountAmount;
  };

  const calculateChange = () => {
    const paymentAmount = parseFloat(payment) || 0;
    return paymentAmount - calculateGrandTotal();
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (cartItems.length === 0) {
      newErrors.cart = 'Cart is empty';
    }
    
    if (!customerName.trim()) {
      newErrors.customerName = 'Customer name is required';
    }
    
    if (paymentMethod === 'cash' || paymentMethod === 'transfer') {
      if (!payment.trim()) {
        newErrors.payment = 'Payment amount is required';
      } else if (parseFloat(payment) < calculateGrandTotal()) {
        newErrors.payment = 'Payment amount is less than total';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    
    const now = new Date().toISOString();
    const grandTotal = calculateGrandTotal();
    const paymentAmount = parseFloat(payment) || 0;
    
    const newSale: Sale = {
      id: uuidv4(),
      items: cartItems,
      total: calculateTotal(),
      discount: parseFloat(discount) || 0,
      grandTotal: grandTotal,
      payment: paymentAmount,
      change: calculateChange(),
      paymentMethod: paymentMethod,
      customerName: customerName,
      customerPhone: customerPhone,
      status: 'completed',
      createdAt: now,
      createdBy: user?.id || 'unknown'
    };
    
    // Update product stock
    cartItems.forEach(item => {
      if (item.type === 'product' && item.productId) {
        updateProductStock(item.productId, -item.quantity);
      }
    });
    
    // Save sale
    const sales = getSales();
    saveSales([...sales, newSale]);
    
    // Navigate to sale detail
    navigate(`/sales/${newSale.id}`);
  };

  return (
    <Layout title="New Sale" showBack={true}>
      <div className="grid md:grid-cols-2 gap-4">
        {/* Left side - Product selection */}
        <div>
          <div className="bg-white rounded-lg shadow p-4 mb-4">
            <h3 className="font-medium mb-3">Select Products</h3>
            
            <div className="relative mb-4">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
              <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
            
            <div className="max-h-64 overflow-y-auto">
              {filteredProducts.length === 0 ? (
                <div className="p-4 text-center text-gray-500">
                  {searchQuery ? 'No products found matching your search' : 'No products available.'}
                </div>
              ) : (
                <ul className="divide-y divide-gray-200">
                  {filteredProducts.map(product => (
                    <li key={product.id} className="py-2">
                      <button
                        onClick={() => addToCart(product)}
                        className="w-full flex justify-between items-center text-left p-2 rounded-lg hover:bg-gray-100"
                        disabled={product.stock <= 0}
                      >
                        <div>
                          <h4 className="font-medium">{product.name}</h4>
                          <p className="text-sm text-gray-500">Stock: {product.stock}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">Rp {product.sellPrice.toLocaleString()}</p>
                          <p className="text-xs text-gray-500">{product.category}</p>
                        </div>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
        
        {/* Right side - Cart */}
        <div>
          <div className="bg-white rounded-lg shadow p-4 mb-4">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-medium">Shopping Cart</h3>
              <ShoppingCart size={20} className="text-amber-500" />
            </div>
            
            {errors.cart && <p className="text-red-500 text-sm mb-2">{errors.cart}</p>}
            {errors.stock && <p className="text-red-500 text-sm mb-2">{errors.stock}</p>}
            
            {cartItems.length === 0 ? (
              <div className="py-8 text-center text-gray-500">
                <ShoppingCart size={32} className="mx-auto mb-2 text-gray-300" />
                <p>Cart is empty</p>
              </div>
            ) : (
              <ul className="divide-y divide-gray-200 max-h-64 overflow-y-auto mb-4">
                {cartItems.map(item => (
                  <li key={item.id} className="py-2">
                    <div className="flex justify-between items-center">
                      <div className="flex-1">
                        <h4 className="font-medium">{item.name}</h4>
                        <p className="text-sm">Rp {item.price.toLocaleString()} x {item.quantity}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center border rounded-lg">
                          <button
                            onClick={() => item.quantity > 1 && updateQuantity(item.id, item.quantity - 1)}
                            className="p-1 hover:bg-gray-100 rounded-l-lg"
                          >
                            <Minus size={16} />
                          </button>
                          <span className="px-2">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="p-1 hover:bg-gray-100 rounded-r-lg"
                          >
                            <Plus size={16} />
                          </button>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="p-1 text-red-500 hover:bg-red-50 rounded-full"
                        >
                          <Trash size={16} />
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
            
            {cartItems.length > 0 && (
              <div>
                <div className="flex justify-between items-center border-t pt-2">
                  <span>Subtotal</span>
                  <span>Rp {calculateTotal().toLocaleString()}</span>
                </div>
                
                <div className="flex justify-between items-center my-2">
                  <span>Discount</span>
                  <div className="flex items-center gap-2">
                    <span>Rp</span>
                    <input
                      type="number"
                      value={discount}
                      onChange={(e) => setDiscount(e.target.value)}
                      className="w-24 px-2 py-1 border border-gray-300 rounded"
                    />
                  </div>
                </div>
                
                <div className="flex justify-between items-center font-bold border-t pt-2">
                  <span>Grand Total</span>
                  <span>Rp {calculateGrandTotal().toLocaleString()}</span>
                </div>
              </div>
            )}
          </div>
          
          {/* Customer and Payment Information */}
          <div className="bg-white rounded-lg shadow p-4 mb-4">
            <h3 className="font-medium mb-3">Customer Information</h3>
            
            <div className="mb-3">
              <label className="block text-sm text-gray-700 mb-1">
                Customer Name*
              </label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg ${errors.customerName ? 'border-red-500' : 'border-gray-300'}`}
              />
              {errors.customerName && <p className="text-red-500 text-sm mt-1">{errors.customerName}</p>}
            </div>
            
            <div className="mb-3">
              <label className="block text-sm text-gray-700 mb-1">
                Phone Number
              </label>
              <input
                type="text"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            
            <h3 className="font-medium mb-3">Payment Information</h3>
            
            <div className="mb-3">
              <label className="block text-sm text-gray-700 mb-1">
                Payment Method
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  className={`py-2 px-3 rounded-lg border ${paymentMethod === 'cash' ? 'bg-amber-100 border-amber-500' : 'border-gray-300'}`}
                  onClick={() => setPaymentMethod('cash')}
                >
                  Cash
                </button>
                <button
                  type="button"
                  className={`py-2 px-3 rounded-lg border ${paymentMethod === 'transfer' ? 'bg-amber-100 border-amber-500' : 'border-gray-300'}`}
                  onClick={() => setPaymentMethod('transfer')}
                >
                  Transfer
                </button>
                <button
                  type="button"
                  className={`py-2 px-3 rounded-lg border ${paymentMethod === 'credit' ? 'bg-amber-100 border-amber-500' : 'border-gray-300'}`}
                  onClick={() => setPaymentMethod('credit')}
                >
                  Credit
                </button>
              </div>
            </div>
            
            {(paymentMethod === 'cash' || paymentMethod === 'transfer') && (
              <>
                <div className="mb-3">
                  <label className="block text-sm text-gray-700 mb-1">
                    Payment Amount*
                  </label>
                  <div className="flex items-center gap-2">
                    <span>Rp</span>
                    <input
                      type="number"
                      value={payment}
                      onChange={(e) => setPayment(e.target.value)}
                      className={`w-full px-3 py-2 border rounded-lg ${errors.payment ? 'border-red-500' : 'border-gray-300'}`}
                    />
                  </div>
                  {errors.payment && <p className="text-red-500 text-sm mt-1">{errors.payment}</p>}
                </div>
                
                <div className="mb-3">
                  <label className="block text-sm text-gray-700 mb-1">
                    Change
                  </label>
                  <p className="px-3 py-2 bg-gray-100 rounded-lg font-medium">
                    Rp {calculateChange().toLocaleString()}
                  </p>
                </div>
              </>
            )}
          </div>
          
          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => navigate('/sales')}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600"
              disabled={cartItems.length === 0}
            >
              Complete Sale
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
