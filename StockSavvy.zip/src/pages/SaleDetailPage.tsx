import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { Download, Printer } from 'lucide-react';
import { useReactToPrint } from 'react-to-print';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import Layout from '../components/Layout';
import { getSales, getStore } from '../utils/storageUtils';
import { Sale, Store } from '../types';

export default function SaleDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [sale, setSale] = useState<Sale | null>(null);
  const [store, setStore] = useState<Store | null>(null);
  const receiptRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (id) {
      const sales = getSales();
      const foundSale = sales.find(s => s.id === id);
      if (foundSale) {
        setSale(foundSale);
      } else {
        navigate('/sales');
      }
    }
    
    const storeInfo = getStore();
    setStore(storeInfo);
  }, [id, navigate]);

  const handlePrint = useReactToPrint({
    content: () => receiptRef.current,
  });

  const handleDownloadPDF = async () => {
    if (!receiptRef.current) return;
    
    const canvas = await html2canvas(receiptRef.current, {
      scale: 2,
      logging: false,
      useCORS: true,
    });
    
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: [80, 210], // Standard thermal receipt width
    });
    
    const imgWidth = 70;
    const pageHeight = 210;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    let heightLeft = imgHeight;
    let position = 0;
    
    pdf.addImage(imgData, 'PNG', 5, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
    
    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 5, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    
    pdf.save(`receipt-${id}.pdf`);
  };

  if (!sale) {
    return (
      <Layout title="Sale Detail" showBack={true}>
        <div className="flex justify-center items-center h-64">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Loading sale details...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Sale Detail" showBack={true}>
      <div className="mb-4 flex flex-wrap justify-between gap-2">
        <h2 className="text-xl font-semibold">Sale #{sale.id.slice(0, 8)}</h2>
        
        <div className="flex space-x-2">
          <button
            onClick={handlePrint}
            className="flex items-center gap-1 px-3 py-1.5 bg-amber-500 text-white rounded-lg hover:bg-amber-600"
          >
            <Printer size={18} />
            <span>Print</span>
          </button>
          
          <button
            onClick={handleDownloadPDF}
            className="flex items-center gap-1 px-3 py-1.5 bg-gray-800 text-white rounded-lg hover:bg-gray-900"
          >
            <Download size={18} />
            <span>Download</span>
          </button>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-4 mb-6 max-w-2xl mx-auto">
        <div 
          ref={receiptRef} 
          className="p-4 bg-white"
          style={{ width: '80mm', margin: '0 auto' }}
        >
          <div className="text-center mb-4">
            <h2 className="text-xl font-bold">{store?.name || 'ALTEZ CELL'}</h2>
            <p className="text-sm">{store?.address || ''}</p>
            <p className="text-sm">{store?.phone || ''}</p>
            {store?.email && <p className="text-sm">{store.email}</p>}
            <div className="border-b border-dashed my-2"></div>
          </div>
          
          <div className="mb-3 text-sm">
            <p><span className="font-medium">Receipt:</span> #{sale.id.slice(0, 8)}</p>
            <p><span className="font-medium">Date:</span> {format(new Date(sale.createdAt), 'dd/MM/yyyy HH:mm')}</p>
            <p><span className="font-medium">Customer:</span> {sale.customerName}</p>
            {sale.customerPhone && <p><span className="font-medium">Phone:</span> {sale.customerPhone}</p>}
            <p><span className="font-medium">Payment:</span> {sale.paymentMethod === 'cash' ? 'Cash' : sale.paymentMethod === 'transfer' ? 'Transfer' : 'Credit'}</p>
          </div>
          
          <div className="border-b border-dashed my-2"></div>
          
          <div className="mb-3">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-1">Item</th>
                  <th className="text-right py-1">Qty</th>
                  <th className="text-right py-1">Price</th>
                  <th className="text-right py-1">Total</th>
                </tr>
              </thead>
              <tbody>
                {sale.items.map((item, index) => (
                  <tr key={item.id} className={index !== sale.items.length - 1 ? 'border-b border-dotted' : ''}>
                    <td className="py-1 text-left">{item.name}</td>
                    <td className="py-1 text-right">{item.quantity}</td>
                    <td className="py-1 text-right">{item.price.toLocaleString()}</td>
                    <td className="py-1 text-right">{item.total.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="border-b border-dashed my-2"></div>
          
          <div className="text-sm mb-4">
            <div className="flex justify-between mb-1">
              <span>Subtotal:</span>
              <span>Rp {sale.total.toLocaleString()}</span>
            </div>
            <div className="flex justify-between mb-1">
              <span>Discount:</span>
              <span>Rp {sale.discount.toLocaleString()}</span>
            </div>
            <div className="flex justify-between font-bold">
              <span>TOTAL:</span>
              <span>Rp {sale.grandTotal.toLocaleString()}</span>
            </div>
            
            {(sale.paymentMethod === 'cash' || sale.paymentMethod === 'transfer') && (
              <>
                <div className="flex justify-between mt-2">
                  <span>Payment:</span>
                  <span>Rp {sale.payment.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Change:</span>
                  <span>Rp {sale.change.toLocaleString()}</span>
                </div>
              </>
            )}
          </div>
          
          <div className="border-b border-dashed my-2"></div>
          
          <div className="text-center text-sm">
            <p>Thank you for shopping with us!</p>
            <p>Please come again</p>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <h3 className="font-medium mb-3">Sale Details</h3>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-sm text-gray-500">Status</p>
            <p className={`font-medium ${sale.status === 'completed' ? 'text-green-600' : 'text-red-600'}`}>
              {sale.status === 'completed' ? 'Completed' : 'Cancelled'}
            </p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Date</p>
            <p className="font-medium">{format(new Date(sale.createdAt), 'dd MMM yyyy, HH:mm')}</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Customer</p>
            <p className="font-medium">{sale.customerName}</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">Payment Method</p>
            <p className="font-medium capitalize">{sale.paymentMethod}</p>
          </div>
        </div>
        
        <h3 className="font-medium mb-2">Items</h3>
        <ul className="divide-y divide-gray-200 mb-4">
          {sale.items.map(item => (
            <li key={item.id} className="py-2">
              <div className="flex justify-between">
                <div>
                  <p className="font-medium">{item.name}</p>
                  <p className="text-sm text-gray-500">{item.quantity} x Rp {item.price.toLocaleString()}</p>
                </div>
                <p className="font-medium">Rp {item.total.toLocaleString()}</p>
              </div>
            </li>
          ))}
        </ul>
        
        <div className="border-t pt-3">
          <div className="flex justify-between mb-1">
            <span>Subtotal</span>
            <span>Rp {sale.total.toLocaleString()}</span>
          </div>
          
          <div className="flex justify-between mb-1">
            <span>Discount</span>
            <span>Rp {sale.discount.toLocaleString()}</span>
          </div>
          
          <div className="flex justify-between font-bold">
            <span>Grand Total</span>
            <span>Rp {sale.grandTotal.toLocaleString()}</span>
          </div>
          
          {(sale.paymentMethod === 'cash' || sale.paymentMethod === 'transfer') && (
            <>
              <div className="flex justify-between mt-2">
                <span>Payment</span>
                <span>Rp {sale.payment.toLocaleString()}</span>
              </div>
              
              <div className="flex justify-between">
                <span>Change</span>
                <span>Rp {sale.change.toLocaleString()}</span>
              </div>
            </>
          )}
        </div>
      </div>
    </Layout>
  );
}
