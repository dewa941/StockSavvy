import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { FileText, Plus, Search } from 'lucide-react';
import Layout from '../components/Layout';
import { getSales } from '../utils/storageUtils';
import { Sale } from '../types';

export default function SalesPage() {
  const [sales, setSales] = useState<Sale[]>([]);
  const [filteredSales, setFilteredSales] = useState<Sale[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadSales();
  }, []);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredSales(sales);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = sales.filter(sale => 
        sale.customerName.toLowerCase().includes(query) ||
        sale.id.toLowerCase().includes(query)
      );
      setFilteredSales(filtered);
    }
  }, [searchQuery, sales]);

  const loadSales = () => {
    const loadedSales = getSales();
    setSales(loadedSales);
    setFilteredSales(loadedSales);
  };

  return (
    <Layout title="Sales">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Sales History</h2>
        <Link 
          to="/sales/new" 
          className="bg-amber-500 text-white p-2 rounded-full hover:bg-amber-600"
        >
          <Plus size={20} />
        </Link>
      </div>

      <div className="relative mb-4">
        <input
          type="text"
          placeholder="Search sales..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
        />
        <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
      </div>

      <div className="bg-white rounded-lg shadow">
        {filteredSales.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            {searchQuery ? 'No sales found matching your search' : 'No sales recorded yet.'}
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {filteredSales.map(sale => (
              <li key={sale.id} className="p-4">
                <Link to={`/sales/${sale.id}`} className="block hover:bg-gray-50 -m-4 p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium">{sale.customerName}</h3>
                      <p className="text-sm text-gray-500">
                        {format(new Date(sale.createdAt), 'dd MMM yyyy, HH:mm')} • 
                        {sale.items.length} items
                      </p>
                      <p className={`text-sm font-semibold ${sale.status === 'completed' ? 'text-green-600' : 'text-red-600'}`}>
                        {sale.status === 'completed' ? 'Completed' : 'Cancelled'} •
                        Rp {sale.grandTotal.toLocaleString()}
                      </p>
                    </div>
                    <FileText size={20} className="text-gray-400" />
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Layout>
  );
}
