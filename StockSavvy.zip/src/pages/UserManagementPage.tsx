import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Pencil, Plus, Search, Trash, UserCog, UserPlus, Users } from 'lucide-react';
import Layout from '../components/Layout';
import { getUsers, saveUsers, getRolePermissions } from '../utils/storageUtils';
import { User } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { useAuth } from '../contexts/AuthContext';

type UserFormData = {
  id?: string;
  username: string;
  name: string;
  role: 'admin' | 'cashier';
  phone: string;
  email?: string;
  permissions?: string[];
};

export default function UserManagementPage() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [formData, setFormData] = useState<UserFormData>({
    username: '',
    name: '',
    role: 'cashier',
    phone: '',
    email: '',
    permissions: []
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredUsers(users);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = users.filter(user => 
        user.name.toLowerCase().includes(query) ||
        user.username.toLowerCase().includes(query) ||
        user.role.toLowerCase().includes(query)
      );
      setFilteredUsers(filtered);
    }
  }, [searchQuery, users]);

  const loadUsers = () => {
    const loadedUsers = getUsers();
    setUsers(loadedUsers);
    setFilteredUsers(loadedUsers);
  };

  const handleDeleteClick = (user: User) => {
    if (user.id === currentUser?.id) {
      alert("You cannot delete your own account");
      return;
    }
    setUserToDelete(user);
    setShowDeleteModal(true);
  };

  const confirmDelete = () => {
    if (userToDelete) {
      const updatedUsers = users.filter(u => u.id !== userToDelete.id);
      saveUsers(updatedUsers);
      setUsers(updatedUsers);
      setFilteredUsers(updatedUsers);
      setShowDeleteModal(false);
      setUserToDelete(null);
    }
  };

  const handleAddUser = () => {
    setFormData({
      username: '',
      name: '',
      role: 'cashier',
      phone: '',
      email: '',
      permissions: []
    });
    setFormErrors({});
    setIsEditing(false);
    setShowModal(true);
  };

  const handleEditUser = (user: User) => {
    setFormData({
      id: user.id,
      username: user.username,
      name: user.name,
      role: user.role,
      phone: user.phone || '',
      email: user.email || '',
      permissions: user.permissions || []
    });
    setFormErrors({});
    setIsEditing(true);
    setShowModal(true);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePermissionChange = (permission: string, isChecked: boolean) => {
    setFormData(prev => {
      const currentPermissions = prev.permissions || [];
      if (isChecked) {
        return { ...prev, permissions: [...currentPermissions, permission] };
      } else {
        return { ...prev, permissions: currentPermissions.filter(p => p !== permission) };
      }
    });
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    
    if (!formData.username.trim()) {
      errors.username = 'Username is required';
    }
    
    if (!formData.name.trim()) {
      errors.name = 'Name is required';
    }
    
    if (!formData.phone.trim()) {
      errors.phone = 'Phone number is required';
    }
    
    // If email is provided, validate it
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Invalid email address';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;
    
    const now = new Date().toISOString();
    const updatedUsers = [...users];
    
    if (isEditing && formData.id) {
      // Update existing user
      const index = updatedUsers.findIndex(u => u.id === formData.id);
      
      if (index !== -1) {
        updatedUsers[index] = {
          ...updatedUsers[index],
          username: formData.username,
          name: formData.name,
          role: formData.role,
          phone: formData.phone,
          email: formData.email,
          permissions: formData.permissions,
          updatedAt: now
        };
      }
    } else {
      // Add new user
      const newUser: User = {
        id: uuidv4(),
        username: formData.username,
        name: formData.name,
        role: formData.role,
        phone: formData.phone,
        email: formData.email,
        permissions: formData.permissions,
        createdAt: now
      };
      
      updatedUsers.push(newUser);
    }
    
    saveUsers(updatedUsers);
    setUsers(updatedUsers);
    setFilteredUsers(updatedUsers);
    setShowModal(false);
  };

  return (
    <Layout title="User Management">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">User List</h2>
        <button 
          onClick={handleAddUser} 
          className="bg-amber-500 text-white p-2 rounded-full hover:bg-amber-600"
        >
          <UserPlus size={20} />
        </button>
      </div>

      <div className="relative mb-4">
        <input
          type="text"
          placeholder="Search users..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
        />
        <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
      </div>

      <div className="bg-white rounded-lg shadow">
        {filteredUsers.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            {searchQuery ? 'No users found matching your search' : 'No users yet.'}
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {filteredUsers.map(user => (
              <li key={user.id} className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">{user.name}</h3>
                    <p className="text-sm text-gray-500">Username: {user.username}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`px-2 py-0.5 text-xs rounded-full ${
                        user.role === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {user.role === 'admin' ? 'Administrator' : 'Cashier'}
                      </span>
                      {user.id === currentUser?.id && (
                        <span className="px-2 py-0.5 text-xs rounded-full bg-blue-100 text-blue-800">
                          Current User
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button 
                      onClick={() => handleEditUser(user)} 
                      className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"
                    >
                      <Pencil size={18} />
                    </button>
                    {user.id !== currentUser?.id && (
                      <button 
                        onClick={() => handleDeleteClick(user)} 
                        className="p-2 text-red-600 hover:bg-red-100 rounded-full"
                      >
                        <Trash size={18} />
                      </button>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* User Form Modal */}
      {showModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4">
              {isEditing ? 'Pencil User' : 'Add New User'}
            </h3>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">
                  Username*
                </label>
                <input
                  id="username"
                  name="username"
                  type="text"
                  value={formData.username}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-lg ${
                    formErrors.username ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                {formErrors.username && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.username}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name*
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-lg ${
                    formErrors.name ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                {formErrors.name && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.name}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1">
                  Role
                </label>
                <select
                  id="role"
                  name="role"
                  value={formData.role}
                  onChange={handleRoleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="admin">Administrator</option>
                  <option value="cashier">Cashier</option>
                  {getRolePermissions().map(role => (
                    <option key={role.id} value={role.name}>{role.name}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number*
                </label>
                <input
                  id="phone"
                  name="phone"
                  type="text"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-lg ${
                    formErrors.phone ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                {formErrors.phone && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.phone}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email || ''}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-lg ${
                    formErrors.email ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                {formErrors.email && (
                  <p className="text-red-500 text-sm mt-1">{formErrors.email}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Permissions
                </label>
                <div className="space-y-2 border border-gray-200 rounded-lg p-3 max-h-40 overflow-y-auto">
                  <div className="flex items-center">
                    <input
                      id="perm_view_products"
                      type="checkbox"
                      checked={formData.permissions?.includes('view_products') || false}
                      onChange={(e) => handlePermissionChange('view_products', e.target.checked)}
                      className="h-4 w-4 text-amber-500 border-gray-300 rounded focus:ring-amber-500"
                    />
                    <label htmlFor="perm_view_products" className="ml-2 text-sm text-gray-700">
                      View Products
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="perm_manage_products"
                      type="checkbox"
                      checked={formData.permissions?.includes('manage_products') || false}
                      onChange={(e) => handlePermissionChange('manage_products', e.target.checked)}
                      className="h-4 w-4 text-amber-500 border-gray-300 rounded focus:ring-amber-500"
                    />
                    <label htmlFor="perm_manage_products" className="ml-2 text-sm text-gray-700">
                      Manage Products (Add/Edit/Delete)
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="perm_manage_sales"
                      type="checkbox"
                      checked={formData.permissions?.includes('manage_sales') || false}
                      onChange={(e) => handlePermissionChange('manage_sales', e.target.checked)}
                      className="h-4 w-4 text-amber-500 border-gray-300 rounded focus:ring-amber-500"
                    />
                    <label htmlFor="perm_manage_sales" className="ml-2 text-sm text-gray-700">
                      Manage Sales
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="perm_view_basic_reports"
                      type="checkbox"
                      checked={formData.permissions?.includes('view_basic_reports') || false}
                      onChange={(e) => handlePermissionChange('view_basic_reports', e.target.checked)}
                      className="h-4 w-4 text-amber-500 border-gray-300 rounded focus:ring-amber-500"
                    />
                    <label htmlFor="perm_view_basic_reports" className="ml-2 text-sm text-gray-700">
                      View Basic Reports
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="perm_view_reports"
                      type="checkbox"
                      checked={formData.permissions?.includes('view_reports') || false}
                      onChange={(e) => handlePermissionChange('view_reports', e.target.checked)}
                      className="h-4 w-4 text-amber-500 border-gray-300 rounded focus:ring-amber-500"
                    />
                    <label htmlFor="perm_view_reports" className="ml-2 text-sm text-gray-700">
                      View Comprehensive Reports
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="perm_manage_settings"
                      type="checkbox"
                      checked={formData.permissions?.includes('manage_settings') || false}
                      onChange={(e) => handlePermissionChange('manage_settings', e.target.checked)}
                      className="h-4 w-4 text-amber-500 border-gray-300 rounded focus:ring-amber-500"
                    />
                    <label htmlFor="perm_manage_settings" className="ml-2 text-sm text-gray-700">
                      Manage Settings
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="perm_manage_users"
                      type="checkbox"
                      checked={formData.permissions?.includes('manage_users') || false}
                      onChange={(e) => handlePermissionChange('manage_users', e.target.checked)}
                      className="h-4 w-4 text-amber-500 border-gray-300 rounded focus:ring-amber-500"
                    />
                    <label htmlFor="perm_manage_users" className="ml-2 text-sm text-gray-700">
                      Manage Users
                    </label>
                  </div>
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  Note: Non-admin users will only see Dashboard, Sales, and Reports menus. The specific permissions above control what they can do within those sections.
                </p>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmit}
                className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600"
              >
                {isEditing ? 'Update User' : 'Add User'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="bg-white rounded-lg p-6 max-w-sm mx-4">
            <h3 className="text-lg font-semibold mb-4">Confirm Delete</h3>
            <p className="mb-6">Are you sure you want to delete user "{userToDelete?.name}"? This action cannot be undone.</p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
