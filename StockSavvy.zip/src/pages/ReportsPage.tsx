import { useState, useEffect, useRef } from 'react';
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  eachDayOfInterval, 
  subMonths, 
  addMonths 
} from 'date-fns';
import { ChartBar, ChevronLeft, ChevronRight, DollarSign, Download, ShoppingCart, TrendingUp } from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend,
  LineChart,
  Line
} from 'recharts';
import Layout from '../components/Layout';
import { getSales, getProducts, getExpenses } from '../utils/storageUtils';
import { useAuth } from '../contexts/AuthContext';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

export default function ReportsPage() {
  const { user, hasPermission } = useAuth();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [monthlySales, setMonthlySales] = useState(0);
  const [monthlyProfit, setMonthlyProfit] = useState(0);
  const [salesData, setSalesData] = useState([]);
  const [productSalesData, setProductSalesData] = useState([]);
  const [categorySalesData, setCategorySalesData] = useState([]);
  const [reportType, setReportType] = useState('sales');
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadReportData();
  }, [currentMonth, reportType]);

  const loadReportData = () => {
    const sales = getSales();
    const products = getProducts();
    const expenses = getExpenses();
    
    // Filter sales for current month
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    
    const monthSales = sales.filter(sale => {
      const saleDate = new Date(sale.createdAt);
      return saleDate >= start && saleDate <= end && sale.status === 'completed';
    });
    
    // Calculate monthly totals
    const totalSales = monthSales.reduce((sum, sale) => sum + sale.grandTotal, 0);
    setMonthlySales(totalSales);
    
    // Calculate profit (simplified)
    let profit = 0;
    monthSales.forEach(sale => {
      sale.items.forEach(item => {
        if (item.type === 'product' && item.productId) {
          const product = products.find(p => p.id === item.productId);
          if (product) {
            profit += (product.sellPrice - product.buyPrice) * item.quantity;
          }
        } else if (item.type === 'service') {
          // For services, assume all is profit
          profit += item.total;
        }
      });
    });
    setMonthlyProfit(profit);
    
    // Prepare daily sales data
    const days = eachDayOfInterval({ start, end });
    const dailyData = days.map(day => {
      const dayStr = format(day, 'yyyy-MM-dd');
      const daySales = monthSales.filter(sale => sale.createdAt.startsWith(dayStr));
      const salesAmount = daySales.reduce((sum, sale) => sum + sale.grandTotal, 0);
      
      let profitAmount = 0;
      daySales.forEach(sale => {
        sale.items.forEach(item => {
          if (item.type === 'product' && item.productId) {
            const product = products.find(p => p.id === item.productId);
            if (product) {
              profitAmount += (product.sellPrice - product.buyPrice) * item.quantity;
            }
          } else if (item.type === 'service') {
            profitAmount += item.total;
          }
        });
      });
      
      // Get day expenses
      const dayExpenses = expenses?.filter(expense => expense.date.startsWith(dayStr)) || [];
      const expenseAmount = dayExpenses.reduce((sum, expense) => sum + expense.amount, 0);
      
      return {
        date: format(day, 'dd'),
        sales: salesAmount,
        profit: profitAmount,
        expenses: expenseAmount
      };
    });
    
    setSalesData(dailyData);
    
    // Product sales data
    const productData = [];
    
    // Count product sales
    const productSaleCount = {};
    const productRevenue = {};
    
    monthSales.forEach(sale => {
      sale.items.forEach(item => {
        if (item.type === 'product' && item.productId) {
          if (!productSaleCount[item.name]) {
            productSaleCount[item.name] = 0;
            productRevenue[item.name] = 0;
          }
          productSaleCount[item.name] += item.quantity;
          productRevenue[item.name] += item.total;
        }
      });
    });
    
    // Convert to array for chart
    for (const [name, quantity] of Object.entries(productSaleCount)) {
      productData.push({
        name: name.length > 15 ? name.substring(0, 15) + '...' : name,
        quantity,
        revenue: productRevenue[name]
      });
    }
    
    // Sort by quantity sold
    productData.sort((a, b) => b.quantity - a.quantity);
    setProductSalesData(productData.slice(0, 5)); // Top 5 products
    
    // Category sales data
    const categoryData = [];
    const categorySaleCount = {};
    
    monthSales.forEach(sale => {
      sale.items.forEach(item => {
        if (item.type === 'product' && item.productId) {
          const product = products.find(p => p.id === item.productId);
          if (product) {
            const category = product.category;
            if (!categorySaleCount[category]) {
              categorySaleCount[category] = 0;
            }
            categorySaleCount[category] += item.total;
          }
        }
      });
    });
    
    for (const [category, total] of Object.entries(categorySaleCount)) {
      categoryData.push({
        name: category,
        value: total
      });
    }
    
    setCategorySalesData(categoryData);
  };

  const prevMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1));
  };

  const nextMonth = () => {
    const next = addMonths(currentMonth, 1);
    if (next <= new Date()) {
      setCurrentMonth(next);
    }
  };

  const generatePDF = async () => {
    if (!reportRef.current) return;
    
    setIsGeneratingPDF(true);
    
    try {
      const canvas = await html2canvas(reportRef.current, {
        scale: 2,
        logging: false,
        useCORS: true,
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });
      
      const imgWidth = 210;
      const pageHeight = 297;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;
      
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      pdf.save(`report-${format(currentMonth, 'yyyy-MM')}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  return (
    <Layout title="Reports">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">
          {hasPermission('view_reports') ? 'Complete Reports' : 'Basic Reports'}
        </h2>
        
        {hasPermission('view_reports') && (
          <button
            onClick={generatePDF}
            disabled={isGeneratingPDF}
            className="flex items-center gap-1 px-3 py-1.5 bg-amber-500 text-white rounded-lg hover:bg-amber-600 disabled:opacity-50"
          >
            <Download size={18} />
            <span>{isGeneratingPDF ? 'Generating...' : 'Export PDF'}</span>
          </button>
        )}
      </div>
      
      <div className="flex justify-between items-center mb-4">
        <button onClick={prevMonth} className="p-2 rounded-full hover:bg-gray-200">
          <ChevronLeft size={20} />
        </button>
        
        <h3 className="text-lg font-medium">
          {format(currentMonth, 'MMMM yyyy')}
        </h3>
        
        <button 
          onClick={nextMonth} 
          className="p-2 rounded-full hover:bg-gray-200"
          disabled={addMonths(currentMonth, 1) > new Date()}
        >
          <ChevronRight size={20} />
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center gap-2 mb-1">
            <ShoppingCart className="text-amber-500" size={20} />
            <span className="text-gray-600">Total Sales</span>
          </div>
          <div className="text-2xl font-bold">Rp {monthlySales.toLocaleString()}</div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center gap-2 mb-1">
            <DollarSign className="text-green-500" size={20} />
            <span className="text-gray-600">Total Profit</span>
          </div>
          <div className="text-2xl font-bold">Rp {monthlyProfit.toLocaleString()}</div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="text-blue-500" size={20} />
            <span className="text-gray-600">Profit Margin</span>
          </div>
          <div className="text-2xl font-bold">
            {monthlySales > 0 ? Math.round((monthlyProfit / monthlySales) * 100) : 0}%
          </div>
        </div>
      </div>
      
      {hasPermission('view_reports') ? (
        <div className="flex justify-start mb-4 border-b">
          <button
            onClick={() => setReportType('sales')}
            className={`px-4 py-2 font-medium ${reportType === 'sales' ? 'border-b-2 border-amber-500 text-amber-500' : 'text-gray-500'}`}
          >
            Sales Report
          </button>
          <button
            onClick={() => setReportType('products')}
            className={`px-4 py-2 font-medium ${reportType === 'products' ? 'border-b-2 border-amber-500 text-amber-500' : 'text-gray-500'}`}
          >
            Product Report
          </button>
        </div>
      ) : (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
          <p className="text-amber-800">As a staff member, you have access to basic sales data only. For detailed analytics, please contact your administrator.</p>
        </div>
      )}
      
      <div ref={reportRef} className="bg-white p-4 rounded-lg shadow">
        {reportType === 'sales' ? (
          <>
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium">Daily Sales & Profit</h3>
              <ChartBar size={20} className="text-amber-500" />
            </div>
            
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={salesData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value) => [`Rp ${value.toLocaleString()}`, '']}
                    labelFormatter={(label) => `Day: ${label}`}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="sales" stroke="#f59e0b" name="Sales" />
                  <Line type="monotone" dataKey="profit" stroke="#10b981" name="Profit" />
                  <Line type="monotone" dataKey="expenses" stroke="#ef4444" name="Expenses" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </>
        ) : (
          <>
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium">Top Selling Products</h3>
              <ChartBar size={20} className="text-amber-500" />
            </div>
            
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={productSalesData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" orientation="left" stroke="#f59e0b" />
                  <YAxis yAxisId="right" orientation="right" stroke="#10b981" />
                  <Tooltip 
                    formatter={(value, name) => [
                      name === 'quantity' ? value : `Rp ${value.toLocaleString()}`, 
                      name === 'quantity' ? 'Units Sold' : 'Revenue'
                    ]}
                  />
                  <Legend />
                  <Bar yAxisId="left" dataKey="quantity" fill="#f59e0b" name="Units Sold" />
                  <Bar yAxisId="right" dataKey="revenue" fill="#10b981" name="Revenue" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </>
        )}
      </div>
    </Layout>
  );
}
