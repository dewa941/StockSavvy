import { ReactNode, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ChartBar, ChevronLeft, FileText, LogOut, Menu, Package, Settings, ShoppingCart, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

type LayoutProps = {
  children: ReactNode;
  title: string;
  showBack?: boolean;
  showMenu?: boolean;
};

export default function Layout({ children, title, showBack = false, showMenu = true }: LayoutProps) {
  const { logout, user, hasPermission } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <header className="bg-amber-500 text-white shadow-md">
        <div className="container mx-auto p-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            {showBack && (
              <button 
                onClick={() => navigate(-1)} 
                className="p-1 rounded-full hover:bg-amber-600"
              >
                <ChevronLeft size={24} />
              </button>
            )}
            <h1 className="text-xl font-semibold">{title}</h1>
          </div>
          
          {showMenu && (
            <button 
              onClick={() => setMenuOpen(!menuOpen)} 
              className="p-1 rounded-full hover:bg-amber-600"
            >
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          )}
        </div>
      </header>

      <main className="flex-1 container mx-auto p-4">
        {children}
      </main>

      {showMenu && (
        <div className={`fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300 ${menuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
          onClick={() => setMenuOpen(false)}
        >
          <div 
            className={`fixed right-0 top-0 h-full w-64 bg-white z-50 shadow-lg transition-transform duration-300 ${menuOpen ? 'translate-x-0' : 'translate-x-full'}`}
            onClick={e => e.stopPropagation()}
          >
            <div className="p-4 bg-amber-500 text-white">
              <h2 className="text-xl font-bold">ALTEZ CELL</h2>
              <p className="text-sm">Mobile Phone Management</p>
              <div className="mt-2 px-2 py-1 bg-amber-200 text-amber-800 rounded-full text-xs inline-block">
                {user?.role === 'admin' ? 'Administrator' : 'Staff Kasir'}
              </div>
            </div>
            
            <nav className="p-4">
              <ul className="space-y-2">
                <li>
                  <Link 
                    to="/" 
                    className={`flex items-center gap-2 p-2 rounded-lg ${location.pathname === '/' ? 'bg-amber-100 text-amber-800' : 'hover:bg-gray-100'}`}
                    onClick={() => setMenuOpen(false)}
                  >
                    <ChartBar size={20} />
                    <span>Dashboard</span>
                  </Link>
                </li>
                {/* For non-admin users, only show dashboard, sales, and reports */}
                {(user?.role === 'admin' || hasPermission('view_products')) && (
                  <li>
                    <Link 
                      to="/products" 
                      className={`flex items-center gap-2 p-2 rounded-lg ${location.pathname.startsWith('/products') ? 'bg-amber-100 text-amber-800' : 'hover:bg-gray-100'}`}
                      onClick={() => setMenuOpen(false)}
                    >
                      <Package size={20} />
                      <span>Products</span>
                      {!hasPermission('manage_products') && <span className="ml-1 text-xs text-gray-500">(View only)</span>}
                    </Link>
                  </li>
                )}
                <li>
                  <Link 
                    to="/sales" 
                    className={`flex items-center gap-2 p-2 rounded-lg ${location.pathname.startsWith('/sales') ? 'bg-amber-100 text-amber-800' : 'hover:bg-gray-100'}`}
                    onClick={() => setMenuOpen(false)}
                  >
                    <ShoppingCart size={20} />
                    <span>Sales</span>
                  </Link>
                </li>
                {(hasPermission('view_reports') || hasPermission('view_basic_reports')) && (
                  <li>
                    <Link 
                      to="/reports" 
                      className={`flex items-center gap-2 p-2 rounded-lg ${location.pathname.startsWith('/reports') ? 'bg-amber-100 text-amber-800' : 'hover:bg-gray-100'}`}
                      onClick={() => setMenuOpen(false)}
                    >
                      <FileText size={20} />
                      <span>Reports</span>
                      {hasPermission('view_basic_reports') && !hasPermission('view_reports') && 
                        <span className="ml-1 text-xs text-gray-500">(Basic)</span>
                      }
                    </Link>
                  </li>
                )}
                {user?.role === 'admin' && (
                  <>
                    {hasPermission('manage_settings') && (
                      <li>
                        <Link 
                          to="/settings" 
                          className={`flex items-center gap-2 p-2 rounded-lg ${location.pathname.startsWith('/settings') ? 'bg-amber-100 text-amber-800' : 'hover:bg-gray-100'}`}
                          onClick={() => setMenuOpen(false)}
                        >
                          <Settings size={20} />
                          <span>Settings</span>
                        </Link>
                      </li>
                    )}
                    
                    {hasPermission('manage_users') && (
                      <li>
                        <Link 
                          to="/users" 
                          className={`flex items-center gap-2 p-2 rounded-lg ${location.pathname.startsWith('/users') ? 'bg-amber-100 text-amber-800' : 'hover:bg-gray-100'}`}
                          onClick={() => setMenuOpen(false)}
                        >
                          <Users size={20} />
                          <span>User Management</span>
                        </Link>
                      </li>
                    )}
                  </>
                )}
              </ul>
            </nav>
            
            <div className="absolute bottom-0 w-full p-4 border-t">
              <button 
                onClick={() => {
                  logout();
                  setMenuOpen(false);
                }}
                className="flex items-center gap-2 p-2 w-full text-left text-red-600 rounded-lg hover:bg-gray-100"
              >
                <LogOut size={20} />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <footer className="bg-white shadow-inner p-2">
        <div className="container mx-auto flex justify-between items-center">
          <Link to="/" className="flex flex-col items-center p-2 flex-1">
            <ChartBar size={20} />
            <span className="text-xs">Dashboard</span>
          </Link>
          
          {(user?.role === 'admin' || hasPermission('view_products')) && (
            <Link to="/products" className="flex flex-col items-center p-2 flex-1">
              <Package size={20} />
              <span className="text-xs">Products</span>
            </Link>
          )}
          
          <Link to="/sales" className="flex flex-col items-center p-2 flex-1">
            <ShoppingCart size={20} />
            <span className="text-xs">Sales</span>
          </Link>
          
          {(hasPermission('view_reports') || hasPermission('view_basic_reports')) && (
            <Link to="/reports" className="flex flex-col items-center p-2 flex-1">
              <FileText size={20} />
              <span className="text-xs">Reports</span>
            </Link>
          )}
          
          {user?.role === 'admin' && hasPermission('manage_settings') && (
            <Link to="/settings" className="flex flex-col items-center p-2 flex-1">
              <Settings size={20} />
              <span className="text-xs">Settings</span>
            </Link>
          )}
        </div>
      </footer>
    </div>
  );
}
